在粪菌移植（FMT）干预的安全性方面，FMT-LUMINate 试验（Phase II）提供了关键的情境依赖性证据。该试验显示，在 NSCLC 队列（抗 PD-1 单药，n=20）中，FMT 联合治疗 ORR 达 80% 且未观察到 3 级及以上治疗相关不良事件（AEs）[P0583]。然而，在黑色素瘤队列（抗 PD-1+ 抗 CTLA-4 双免，n=20）中，尽管 ORR 为 75%，但 65% 的患者经历了 3 级及以上 AEs，其中腹泻/结肠炎占 20%，心肌炎发生率高达 15%（显著高于文献报道的<1%）[P0583]。严重毒性的中位起病时间提前至 40 天（文献通常 60 天）[P0583]。相比之下，MITRIC 试验在 ICI 难治人群中显示 ORR 为 0%，提示干预效果在初治与难治人群间存在显著异质性 [P0578]。荟萃分析量化 FMT 联合 ICI 的总体 3-4 级 AE 发生率为 37%，双药方案下毒性风险显著升高 [P0212]。

供体微生物组特征与毒性事件存在因果关联。基于 Bray-Curtis 指数的无监督聚类将供体分为 Cluster A 与 Cluster B（含供体 5、11）[P0583]。Cluster B 以 Segatella copri、Prevotella sp. Marseille-P4119 等高丰度为特征 [P0583]。接受 Cluster B 供体 FMT 的黑色素瘤患者中，这些菌属显著富集并与 3 级及以上 AEs 强相关 [P0583]。流式分析显示 S. copri 定植与外周血 CD4+ T 细胞亚群比例增加相关，且该毒性仅在双 ICI 背景下显现，单药抗 PD-1 治疗中未观察到类似风险 [P0583]。这表明特定菌属与 ICI 骨架的交互作用是触发严重 irAEs 的决定性因素 [P0583]。

| 供体聚类 | 特征菌属 | ICI 方案背景 | 主要毒性事件 | 发生率/关联强度 |
| :--- | :--- | :--- | :--- | :--- |
| Cluster A (非 Prevotella 富集) | 所给材料未提供 | 双免 (抗 PD-1+ 抗 CTLA-4) | 基线安全性 | 所给材料未提供具体数值 |
| Cluster B (Prevotella/Segatella 富集) | Segatella copri, Prevotella sp. Marseille-P4119, P. stercorea | 双免 (抗 PD-1+ 抗 CTLA-4) | 3 级及以上 AEs, 心肌炎 | 3 级及以上 AEs 强相关 (P < 0.001), 心肌炎 15% |