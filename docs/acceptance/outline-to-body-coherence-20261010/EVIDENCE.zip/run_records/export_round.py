"""Export public round evidence, costs and paired drafts; never export ledgers/keys."""
from collections import Counter
import difflib
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import zipfile

C = Path(__file__).resolve().parent
R = C.parent
W = R / "worktree"
D = W / "docs/acceptance/outline-to-body-coherence-20261010"
sys.path.insert(0, str(W))
from optomind_research.runtime.upgrade3.delivery_citations import build_delivery_citation_map

def read(p): return json.loads(p.read_text(encoding="utf-8"))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, j): p.write_text(json.dumps(j, ensure_ascii=False, indent=2), encoding="utf-8")

def main():
    D.mkdir(parents=True, exist_ok=True)
    startup = read(C / "STARTUP.json")
    reports = {}
    for arm, root in {"baseline": C / "baseline", "chapter_coherence": C / "chapter_coherence/body"}.items():
        report = read(root / "RUN_REPORT.json")
        assert report["complete_units"] == 5 and report["requested_generation_complete"], (arm, "incomplete pilot")
        reports[arm] = (root, report)
    evidence = []
    stats = {}
    bodies = {}
    counts = {}
    units = [(ch, unit) for ch, units in startup["selection"].items() for unit in units]
    for arm, (root, report) in reports.items():
        texts, stats[arm], bodies[arm], counts[arm] = [], [], {}, Counter()
        catalog = read(root / "assembled/REFERENCES.json")
        for ch, unit in units:
            row = next(u for u in report["units"] if u["chapter_id"] == ch and u["unit_id"] == unit)
            attempt = Path(row["attempt_dir"])
            original = (attempt / "UNIT_BODY.md").read_text(encoding="utf-8")
            body = row["quality"]["body_markdown"]
            bodies[arm][(ch, unit)] = body
            texts += [f"## {ch}:{unit}\n\n{body}\n"]
            mapping = build_delivery_citation_map(final_handle_draft=body, identity_catalogs=[catalog])
            for m in re.findall(r"\[([^\]]+)\]", body):
                if re.fullmatch(r"(?:[\w-]+::)?P\d+", m): counts[arm][m] += 1
            stats[arm].append({"chapter_id": ch, "unit_id": unit, "initial_chars": len(original),
                "adopted_chars": len(body), "initial_equals_adopted": original == body,
                "unique_paper_identities": mapping["reference_count"], "unknown_citations": mapping["unknown_handles"],
                "quality_calls": row["quality"]["model_calls"], "quality_status": row["quality"]["status"]})
            # Saved requests/returns, prior failed attempt, original and adopted body.
            for p in attempt.parent.rglob("*"):
                if p.is_file() and p.suffix in {".json", ".md", ".txt"} and "reparse_history" not in p.parts:
                    evidence.append((p, str(Path(arm) / p.relative_to(root))))
            messages = Path(row["messages_path"])
            evidence.append((messages, str(Path(arm) / messages.relative_to(root))))
        (D / (arm.upper() + "_ADOPTED.md")).write_text("\n".join(texts), encoding="utf-8")
        for p in [root / "RUN_REPORT.json", root / "RUN_IDENTITY.json", root / "DELIVERY_REPORT.json",
                  root / "assembled/ASSEMBLY_SUMMARY.json", root / "assembled/REFERENCES.json"]:
            if p.exists(): evidence.append((p, str(Path(arm) / p.relative_to(root))))
    comparison = []
    for ch, unit in units:
        comparison.append(f"## {ch}:{unit}\n\n```diff\n" + "".join(difflib.unified_diff(
            bodies["baseline"][(ch, unit)].splitlines(True), bodies["chapter_coherence"][(ch, unit)].splitlines(True),
            fromfile="fresh-baseline", tofile="fresh-chapter-coherence")) + "\n```\n")
    (D / "PAIRED_DIFF.md").write_text("\n".join(comparison), encoding="utf-8")
    write(D / "COMPARISON_METRICS.json", {"stats": stats, "citation_occurrences": {k: dict(v) for k,v in counts.items()},
        "interpretation": "Counts locate content; adoption decision is based on ROOT_REVIEW.md, not length or citation count."})
    # Exact physical-call attribution; project/account amounts overlap and are not added.
    call_arm = {}
    for arm, (root, _) in reports.items():
        for p in root.rglob("RAW_RESPONSE.json"):
            if "reparse_history" in p.parts: continue
            j = read(p)
            if j.get("call_id"): call_arm[j["call_id"].split(":key", 1)[0]] = arm
    with sqlite3.connect("file:" + str(R / "budget.sqlite") + "?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        ledger_rows = [dict(row) for row in db.execute("select call_id,status,amount_cny,actual_cny,returned_model,finish_reason,created_at,usage_json from reservations")]
    settled = sum(float(row["actual_cny"] or 0) for row in ledger_rows if row["status"] == "settled")
    holds = sum(float(row["amount_cny"] or 0) for row in ledger_rows if row["status"] in {"reserved", "uncertain"})
    selected_rows = []
    arm_cost = Counter()
    round_started = datetime.fromisoformat(startup["started_utc"]).timestamp()
    for row in ledger_rows:
        arm = call_arm.get(row["call_id"].split(":key", 1)[0])
        # The request fingerprint can recur in an independent output directory;
        # attribute physical fees only within this round's persisted start time.
        if arm and float(row["created_at"]) >= round_started:
            row["arm"] = arm
            row["usage"] = json.loads(row.pop("usage_json") or "{}")
            selected_rows.append(row)
            if row["status"] == "settled": arm_cost[arm] += float(row["actual_cny"] or 0)
    costs = {"project_cap_cny": 60, "starting_settled_cny": startup["starting_settled_cny"],
        "round_new_settled_cny": settled-startup["starting_settled_cny"], "by_arm_cny": dict(arm_cost),
        "project_total_settled_cny": settled, "open_holds_cny": holds, "available_cny": 60-settled-holds,
        "physical_calls": selected_rows, "account_budget_is_overlapping_not_additive": True,
        "historical_independent_max_cny": 1.025472, "round_max_calls": 0}
    write(D / "COSTS.json", costs)
    for p in C.iterdir():
        if p.is_file() and p.suffix in {".json", ".log", ".py", ".md"} and p.name != "FORMAL_FULL_PRIOR_RUN_REPORT.json":
            evidence.append((p, "run_records/" + p.name))
    # Explicitly keep no SQLite, credentials, downloaded PDFs or source fulltext files.
    unique = {}
    for p, name in evidence: unique[name] = p
    secret_pattern = re.compile(rb"(?:sk-[A-Za-z0-9_-]{24,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|Bearer\s+[A-Za-z0-9._-]{24,})")
    manifest = []
    with zipfile.ZipFile(D / "EVIDENCE.zip", "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out:
        for name, p in sorted(unique.items()):
            content = p.read_bytes()
            if secret_pattern.search(content): raise RuntimeError("Credential-shaped value detected in " + name)
            out.writestr(name.replace("\\", "/"), content)
            manifest.append({"path": name.replace("\\", "/"), "bytes": len(content), "sha256": sha(p)})
    write(D / "EVIDENCE_MANIFEST.json", manifest)
    write(D / "SOURCE_VERSIONS.json", {"baseline_tested": startup["baseline_production_source"],
        "candidate_tested": read(C / "chapter_coherence_live_entry_fix_retry_COMMAND.json")["source_commit"],
        "final_product_source": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=W, text=True).strip(),
        "input_sha256": startup["input_sha256"], "archive_commit": "See containing Git commit, separate from tested source.",
        "old_complete_run": "02167134f3eb8a9e88e3fb98812e9a2ec6f2da95/docs/acceptance/outline-to-body-20261010"})
    print(json.dumps({"directory": str(D), "zip_bytes": (D/"EVIDENCE.zip").stat().st_size,
        "entries": len(manifest), "costs": {k:v for k,v in costs.items() if k!='physical_calls'}}, ensure_ascii=False))

if __name__ == "__main__": main()
