"""Verify the selected default via the normal CLI, without keys or --run."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

C = Path(__file__).resolve().parent
R = C.parent
W = R / "worktree"
startup = json.loads((C / "STARTUP.json").read_text(encoding="utf-8"))
source = Path(startup["input_path"])
before = hashlib.sha256(source.read_bytes()).hexdigest()
output = C / "formal_default_preview"
command = [sys.executable, "-X", "utf8", "run_review_harness.py", "--delivery-start", "body",
           "--delivery-input", str(source), "--delivery-out", str(output),
           "--tokenizer", r"F:\OptoMind-Review-2\data\tokenizers\qwen3_5_9b\tokenizer.json",
           "--key-file", str(C / "INTENTIONALLY_ABSENT_KEY_NO_API.txt")]
with (C / "FORMAL_DEFAULT_PREVIEW.log").open("w", encoding="utf-8") as log:
    completed = subprocess.run(command, cwd=W, stdout=log, stderr=subprocess.STDOUT)
report = json.loads((output / "body/DELIVERY_REPORT.json").read_text(encoding="utf-8"))
settings = report.get("effective_settings", {})
audit = {"command": command, "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=W, text=True).strip(),
         "exit_code": completed.returncode, "original_units": report.get("original_units"),
         "model_calls": report.get("model_calls"), "effective_settings": settings,
         "input_sha256": before, "input_unchanged": before == hashlib.sha256(source.read_bytes()).hexdigest(),
         "credential_file_exists": Path(command[-1]).exists(),
         "explicit_quality_or_version_flags": False}
audit["passed"] = bool(report.get("original_units") == 29 and report.get("model_calls") == 0
    and settings.get("body_version") == "baseline" and settings.get("quality_control") is True
    and settings.get("article_edit") is True and audit["input_unchanged"] and not audit["credential_file_exists"])
(C / "FORMAL_DEFAULT_PREVIEW.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(audit, ensure_ascii=False, indent=2))
raise SystemExit(0 if audit["passed"] else 1)
