"""Native product CLI: complete accepted book, no credential read permitted."""
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

C = Path(__file__).resolve().parent
R = C.parent
W = R / "worktree"
INPUT = Path(r"F:\OptoMind-Review-2\outputs\legacy_unit_plus_acceptance_20261010_30cny\input\6d6ae867ceae5c88f25d36f88087925341af5cf82f1672680157a3588d14e5f7\FULL_BODY_INPUT.json")
ROOT = R / "fresh_full"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (C / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")

def rows():
    with sqlite3.connect("file:" + str(R / "budget.sqlite") + "?mode=ro", uri=True) as db:
        return {row[0] for row in db.execute("select call_id from reservations")}

before_files = {str(p.relative_to(ROOT)): digest(p) for p in ROOT.rglob("*")
                if p.is_file() and p.name in {"RAW_RESPONSE.json", "ORIGINAL_HANDLES.md", "CANDIDATE_HANDLES.md"}}
before_rows = rows()
(C / "FORMAL_FULL_PRIOR_RUN_REPORT.json").write_bytes((ROOT / "RUN_REPORT.json").read_bytes())
command = [sys.executable, "-X", "utf8", "scripts/upgrade3/legacy_unit_writer.py",
    "--input", str(INPUT), "--output-dir", str(ROOT), "--body-version", "baseline",
    "--quality-control", "--article-edit", "--output-tokens", "32768", "--thinking-budget", "8192",
    "--budget-limit", "60", "--budget-scope", "outline-to-body-20261010-60cny",
    "--ledger", str(R / "budget.sqlite"),
    "--account-ledger", r"F:\OptoMind-Review-2\local_accounting\qwen_first_20261010_300cny\budget.sqlite",
    "--account-budget-limit", "300", "--account-mapping-dir", str(R / "accounting_meta" / "physical_calls"),
    "--key-file", str(C / "INTENTIONALLY_ABSENT_KEY_NO_API.txt"), "--key-index", "1",
    "--tokenizer", r"F:\OptoMind-Review-2\data\tokenizers\qwen3_5_9b\tokenizer.json", "--run"]
save("FORMAL_FULL_COMMAND.json", {"command": command, "reason": "cached complete book through normal product API, missing credential prevents any new API call"})
with (C / "FORMAL_FULL_CACHED.log").open("w", encoding="utf-8") as log:
    result = subprocess.run(command, cwd=W, stdout=log, stderr=subprocess.STDOUT)
report = json.loads((ROOT / "DELIVERY_REPORT.json").read_text(encoding="utf-8"))
selected = report.get("selected_body", {})
preserved = all((ROOT / p).is_file() and digest(ROOT / p) == sha for p, sha in before_files.items())
new_rows = rows() - before_rows
audit = {"source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=W, text=True).strip(),
    "command_exit_code": result.returncode, "original_units": report.get("original_units"),
    "complete_units": report.get("complete_units"), "requested_generation_complete": report.get("requested_generation_complete"),
    "model_calls": report.get("model_calls"), "effective_settings": report.get("effective_settings"),
    "selected_body": selected, "prior_raw_and_manuscripts_unchanged": preserved,
    "new_reservations": sorted(new_rows), "credential_file_exists": Path(command[command.index("--key-file") + 1]).exists()}
audit["passed"] = bool(report.get("complete_units") == 29 and report.get("model_calls") == 0 and preserved
    and not new_rows and selected.get("source") == "article_edit" and selected.get("status") == "complete")
save("FORMAL_FULL_CACHED_VALIDATION.json", audit)
print(json.dumps(audit, ensure_ascii=False, indent=2))
raise SystemExit(0 if audit["passed"] else 1)
