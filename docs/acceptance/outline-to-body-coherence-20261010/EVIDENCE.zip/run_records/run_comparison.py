"""Fixed two-arm comparison through the product CLI, using the original ledger.

No prompts, scientific feedback, manuscript, or response modification is supplied
by this driver. All writer/quality/assembly work is performed by the product.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
WORKTREE = PROJECT / "worktree"


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--arm", choices=("baseline", "chapter_coherence", "both"), default="both")
    parser.add_argument("--retry-failed", action="store_true", help="One explicit retry after an engineering startup fix; keep the prior attempt.")
    args = parser.parse_args()
    startup = json.loads((ROOT / "STARTUP.json").read_text(encoding="utf-8"))
    source = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=WORKTREE, text=True).strip()
    dirty = subprocess.check_output(["git", "diff", "--name-only"], cwd=WORKTREE, text=True).strip()
    if dirty and args.arm != "baseline":
        raise RuntimeError("Commit the tested source before preview/live; preserve and identify all changes.")
    phases = ("baseline", "chapter_coherence") if args.arm == "both" else (args.arm,)
    for arm in phases:
        output = ROOT / arm
        if arm == "baseline":
            tested_worktree = ROOT / "baseline_source"
            tested_source = startup["baseline_production_source"]
            entry = ["scripts/upgrade3/legacy_unit_writer.py", "--input", startup["input_path"], "--output-dir", str(output)]
        else:
            tested_worktree = WORKTREE
            tested_source = source
            entry = ["run_review_harness.py", "--delivery-start", "body", "--delivery-input", startup["input_path"],
                     "--delivery-out", str(output), "--body-version", arm, "--no-article-edit"]
        command = [sys.executable, "-X", "utf8", *entry,
                   "--quality-control", "--output-tokens", "32768", "--thinking-budget", "8192",
                   "--budget-limit", "60", "--budget-scope", "outline-to-body-20261010-60cny",
                   "--ledger", str(PROJECT / "budget.sqlite"),
                   "--account-ledger", r"F:\OptoMind-Review-2\local_accounting\qwen_first_20261010_300cny\budget.sqlite",
                   "--account-budget-limit", "300",
                   "--account-mapping-dir", str(PROJECT / "accounting_meta" / "physical_calls"),
                   "--key-file", r"F:\OptoMind-Review-2\api_keys\qwen-api-key.txt", "--key-index", "1",
                   "--tokenizer", r"F:\OptoMind-Review-2\data\tokenizers\qwen3_5_9b\tokenizer.json"]
        for chapter, units in startup["selection"].items():
            for unit in units:
                command.extend(["--only-unit", f"{chapter}:{unit}"])
        if args.live:
            command.append("--run")
        if args.retry_failed:
            if not args.live:
                raise ValueError("Retry requires --live")
            command.append("--retry-failed")
        record = {"source_commit": tested_source, "source_directory": str(tested_worktree), "arm": arm, "execution_mode": "live" if args.live else "preview",
                  "started_utc": datetime.now(timezone.utc).isoformat(), "command": command,
                  "input_sha256": hashlib.sha256(Path(startup["input_path"]).read_bytes()).hexdigest(),
                  "output": str(output), "uses_product_entry": entry[0]}
        tag = record['execution_mode'] + ("_entry_fix_retry" if args.retry_failed else "")
        write(f"{arm}_{tag}_COMMAND.json", record)
        log = ROOT / f"{arm}_{tag}.log"
        with log.open("wb") as stream:
            child = subprocess.Popen(command, cwd=tested_worktree, stdout=stream, stderr=subprocess.STDOUT)
            record["pid"] = child.pid
            write("CURRENT_PROCESS.json", record)
            write(f"{arm}_CURRENT_PROCESS.json", record)
            code = child.wait()
        record.update(returncode=code, finished_utc=datetime.now(timezone.utc).isoformat())
        write(f"{arm}_{tag}_PROCESS.json", record)
        write("CURRENT_PROCESS.json", record)
        write(f"{arm}_CURRENT_PROCESS.json", record)
        print(json.dumps({"arm": arm, "mode": record["execution_mode"], "returncode": code, "log": str(log)}, ensure_ascii=False), flush=True)
        if code not in (0, 2):
            raise RuntimeError(f"Product entry failed: {arm}, see {log}")


if __name__ == "__main__":
    main()
